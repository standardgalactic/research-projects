import os, json, subprocess
def test_sample_memory_written():
    # Ensure sample exists
    p='samples/sample_doc.txt'
    assert os.path.exists(p)
    # We can't run ollama here, but ensure the sample output file is present
    out='output_samples/sample_memory.json'
    assert os.path.exists(out)
    j=json.load(open(out))
    assert 'memory_id' in j and j['chunk_index']==1
