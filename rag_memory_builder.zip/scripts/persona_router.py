#!/usr/bin/env python3
"""Persona router: constructs persona prompts, calls Ollama synchronously, and returns structured JSON results.
This module intentionally shells out to 'ollama run granite3.2:8b' for local LLM calls.
Replace model name or call method as needed.
"""
import subprocess, json, shlex, sys, uuid, datetime

PERSONA_PROMPTS = {
    "archivist": "You are the Archivist (RAG-01). Preserve optionality, provenance and lineage. Respond in JSON with keys: keep, delete, tags, rationale.",
    "formalist": "You are the Formalist (RAG-02). Return JSON: keep, delete, compression_plan, proof_obligations, rationale.",
    "synthesist": "You are the Synthesist (RAG-03). Return JSON: keep, delete, branches, fertility_score, rationale.",
    "strategist": "You are the Strategist (RAG-04). Return JSON: keep, delete, leverage_points, next_action, traction_risk, rationale."
}

def call_ollama(prompt: str, stdin_text: str) -> str:
    """Call ollama CLI and return stdout as string."""
    # Build command. Note: adjust model tag to your local model name.
    cmd = f"ollama run granite3.2:8b \"{prompt}\""
    try:
        # Use subprocess to pass stdin_text
        proc = subprocess.run(cmd, input=stdin_text.encode('utf-8'), shell=True, check=True, capture_output=True)
        return proc.stdout.decode('utf-8')
    except subprocess.CalledProcessError as e:
        # Bubble error message with stderr
        raise RuntimeError(f"Ollama call failed: {e.stderr.decode('utf-8')}") from e

def analyze_with_persona(persona: str, chunk_text: str) -> dict:
    prompt = PERSONA_PROMPTS[persona] + "\nMemory chunk:\n" + chunk_text + "\nRespond strictly with JSON only."
    out = call_ollama(prompt, chunk_text)
    # Try to parse JSON; if parsing fails, wrap raw output.
    try:
        return json.loads(out.strip())
    except json.JSONDecodeError:
        return {"_raw_output": out.strip(), "_parse_error": True}

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: persona_router.py <persona> <chunk_file>")
        sys.exit(2)
    persona = sys.argv[1]
    chunk_file = sys.argv[2]
    with open(chunk_file,'r',encoding='utf-8') as f:
        txt = f.read()
    res = analyze_with_persona(persona, txt)
    print(json.dumps(res, indent=2))
