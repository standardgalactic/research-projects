#!/usr/bin/env bash
# Sequential RAG memory builder using Ollama (granite) and the curator orchestration.
# Usage: bash rag_memory_builder.sh /path/to/directory_with_txt_files
set -euo pipefail
DIR="${1:-.}"
MEM_DIR="${DIR%/}/memories"
PROGRESS_FILE="${DIR%/}/progress.log"
SUMMARY_FILE="${DIR%/}/source-control.txt"
mkdir -p "$MEM_DIR"
touch "$PROGRESS_FILE"
touch "$SUMMARY_FILE"
echo "Starting RAG memory builder at $(date)" >> "$PROGRESS_FILE"

for file in "$DIR"/*.txt; do
  [ -f "$file" ] || continue
  base=$(basename "$file" .txt)
  if grep -Fxq "$base" "$PROGRESS_FILE"; then
    echo "Skipping already processed $file" >> "$PROGRESS_FILE"
    continue
  fi
  echo "Processing $file" >> "$PROGRESS_FILE"
  # split into chunks of ~282 lines to match your earlier script
  tmpdir=$(mktemp -d)
  split -l 282 "$file" "$tmpdir/chunk_"
  idx=0
  for chunk in "$tmpdir"/chunk_*; do
    idx=$((idx+1))
    memfile="${MEM_DIR}/${base}-${idx}.memory"
    echo "Processing chunk $chunk -> $memfile" >> "$PROGRESS_FILE"
    # 1) produce a summary (call Ollama)
    echo "### $base - chunk $idx" >> "$SUMMARY_FILE"
    # summary call (replace prompt as desired)
    ollama run granite3.2:8b "Summarize in detail and explain the main points:" < "$chunk" | tee -a "$SUMMARY_FILE"
    echo "" >> "$SUMMARY_FILE"
    summary=$(ollama run granite3.2:8b "Summarize in detail in one paragraph (JSON: {"summary": "..."}) Please return only JSON." < "$chunk" || true)
    # 2) call curator (which runs personas sequentially and returns decision)
    curator_output=$(python3 "$(dirname "$0")/curator.py" "-" < "$chunk")
    # 3) build memory JSON (include raw text)
    created_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    uuid=$(python3 - <<'PY'
import uuid, sys
print(str(uuid.uuid4()))
PY
)
    cat > "$memfile" <<EOF
{
  "memory_id": "${uuid}",
  "chunk_source": "${base}.txt",
  "chunk_index": ${idx},
  "text": $(python3 - <<'PY'
import json,sys
txt=sys.stdin.read()
print(json.dumps(txt))
PY
) ,
  "summary": $(python3 - <<'PY'
import json,sys,subprocess
# print raw summary string if available, else empty
s=''PY
) ,
  "persona_analysis": {},
  "curator": $(python3 - <<'PY'
import json,sys
# write curator output that curator.py printed to stdout - read from stdin (we passed in $curator_output)
print(json.dumps(json.loads(sys.stdin.read())))
PY
<<< "$curator_output"),
  "tags": [],
  "state_machine": {"state":"candidate","reason":"initial processing"},
  "created_at": "${created_at}",
  "embedding_ready": false
}
EOF
    echo "Wrote memory $memfile" >> "$PROGRESS_FILE"
  done
  rm -rf "$tmpdir"
  echo "$base" >> "$PROGRESS_FILE"
done

echo "Completed at $(date)" >> "$PROGRESS_FILE"
