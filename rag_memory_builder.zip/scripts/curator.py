#!/usr/bin/env python3
"""Curator orchestrator: runs personas iteratively and decides when consensus/confidence is good enough.
Saves the debate transcript and final routing decision.
"""
import subprocess, json, sys, uuid, datetime, os
from typing import Dict, Any

PERSONAS = ['archivist','formalist','synthesist','strategist']

# Tweaks
MAX_ROUNDS = 3        # maximum debate rounds
CONFIDENCE_THRESHOLD = 0.6  # curator accepts if top weight >= threshold

def run_persona(persona: str, chunk_text: str) -> Dict[str,Any]:
    # Call persona_router.py which shells out to ollama
    script_path = os.path.join(os.path.dirname(__file__), 'persona_router.py')
    proc = subprocess.run([script_path, persona, '-'], input=chunk_text.encode('utf-8'), capture_output=True)
    out = proc.stdout.decode('utf-8')
    try:
        return json.loads(out)
    except Exception:
        return {'_raw': out}

def score_persona_outputs(persona_outputs: Dict[str, Dict]) -> Dict[str,float]:
    # Heuristic scoring of persona outputs -> weights
    # If persona returns 'fertility_score' or 'traction_risk' we can map to weight.
    weights = {p:0.25 for p in PERSONAS}  # base
    # Simple heuristics:
    if 'formalist' in persona_outputs and isinstance(persona_outputs['formalist'], dict):
        # if formalist returns proof obligations -> bump formalist
        if persona_outputs['formalist'].get('proof_obligations'):
            weights['formalist'] += 0.2
    if 'synthesist' in persona_outputs and isinstance(persona_outputs['synthesist'], dict):
        fs = persona_outputs['synthesist'].get('fertility_score')
        if isinstance(fs,(int,float)):
            weights['synthesist'] += min(0.5, fs/10.0)
    if 'strategist' in persona_outputs and isinstance(persona_outputs['strategist'], dict):
        tr = persona_outputs['strategist'].get('traction_risk')
        # lower traction risk (i.e., actionable) increases strategist weight
        try:
            if tr and tr.lower() == 'low':
                weights['strategist'] += 0.2
        except Exception:
            pass
    # normalize to sum=1
    s = sum(weights.values())
    for k in weights:
        weights[k] = round(weights[k]/s,3)
    return weights

def curator_debate_and_decide(chunk_text: str) -> Dict[str,Any]:
    debate_log = []
    persona_outputs = {}
    for round_idx in range(1, MAX_ROUNDS+1):
        debate_log.append(f"=== ROUND {round_idx} ===\n")
        # run all personas sequentially (blocking)
        for p in PERSONAS:
            debate_log.append(f"-- {p} OUTPUT --\n")
            try:
                out = run_persona(p, chunk_text)
            except Exception as e:
                out = {"_error": str(e)}
            persona_outputs[p] = out
            debate_log.append(json.dumps(out, indent=2) + "\n")
        # score outputs into weights and check confidence
        weights = score_persona_outputs(persona_outputs)
        top_persona = max(weights, key=lambda k: weights[k])
        top_weight = weights[top_persona]
        debate_log.append(f"Round {round_idx} weights: {weights}\n")
        # Decide if confident enough
        if top_weight >= CONFIDENCE_THRESHOLD:
            decision = {'primary_owner': top_persona, 'weights': weights, 'rounds': round_idx}
            return {'decision': decision, 'debate_log': '\n'.join(debate_log), 'persona_outputs': persona_outputs}
        # else, optionally modify chunk_text or re-run: current simple policy just continues to next round
    # fallback: pick top anyway
    weights = score_persona_outputs(persona_outputs)
    top_persona = max(weights, key=lambda k: weights[k])
    return {'decision': {'primary_owner': top_persona, 'weights': weights, 'rounds': MAX_ROUNDS}, 'debate_log': '\n'.join(debate_log), 'persona_outputs': persona_outputs}

if __name__ == '__main__':
    if len(sys.argv) < 2:
        print('Usage: curator.py <chunk_file_or_-for-stdin>')
        sys.exit(2)
    if sys.argv[1] == '-':
        chunk_text = sys.stdin.read()
    else:
        with open(sys.argv[1],'r',encoding='utf-8') as f:
            chunk_text = f.read()
    res = curator_debate_and_decide(chunk_text)
    print(json.dumps(res))
