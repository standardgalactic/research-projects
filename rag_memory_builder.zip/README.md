RAG Memory Builder (Ollama Granite Integration)
===============================================

This package provides a sequential pipeline that:
 - splits input .txt files into chunks
 - for each chunk: runs a summary, runs 4 persona analyses (archivist, formalist, synthesist, strategist),
   then runs the curator to arbitrate and iterate until confidence is reached
 - writes one self-contained .memory JSON file per chunk (includes raw text, summary, persona outputs,
   curator decision, lifecycle, tags, and curator debate transcript)

Assumptions/Requirements
 - Ollama is installed and the 'granite3.2:8b' (or your preferred granite model) is available locally.
 - The `ollama` CLI is on PATH and callable from shell scripts.
 - The environment has Python 3.11+ available.

Important: This environment doesn't call Ollama; scripts include the real commands you should run on your machine.

Files created:
 - scripts/rag_memory_builder.sh  -- main bash pipeline (sequential)
 - scripts/persona_router.py     -- Python helper to build persona prompts & call Ollama
 - scripts/curator.py            -- Python orchestrator for iterative debate (uses persona_router)
 - memory_schema.json            -- JSON schema for .memory files
 - samples/sample_doc.txt        -- sample input to test the pipeline
 - output_samples/sample_memory.json -- example output after running pipeline once
 - tests/test_integration.py     -- simple pytest to validate a generated memory file

Usage (on your machine)
-----------------------
1. Place text files to process in a directory, e.g. ./to_process/
2. Update the first lines of scripts/rag_memory_builder.sh to point to your paths if needed.
3. Run the script:
   bash scripts/rag_memory_builder.sh ./to_process/

4. Generated .memory files will appear in ./memories/

Notes:
 - The pipeline is sequential by design (safer for limited hardware).
 - Curator saves the full debate transcript into each .memory file under curator['debate_log'].
 - You can tweak thresholds (confidence, max rounds) inside scripts/curator.py
