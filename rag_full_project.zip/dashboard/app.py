#!/usr/bin/env python3
import streamlit as st
import json, os, datetime, numpy as np
from pathlib import Path
from sentence_transformers import SentenceTransformer

MEMORIES_DIR = Path(os.getenv("MEMORIES_DIR", "to_process/memories"))
EMBED_MODEL = "all-MiniLM-L6-v2"
st.set_page_config(page_title="RAG Curator Dashboard", layout="wide")

@st.cache_resource
def load_model():
    return SentenceTransformer(EMBED_MODEL)

model = load_model()

def load_memories():
    return sorted(MEMORIES_DIR.glob("*.memory"), key=lambda p: p.stat().st_mtime, reverse=True)

def embed_and_save(mem_path, text):
    vec = model.encode(text[:8000], normalize_embeddings=True)
    vec_path = mem_path.with_suffix(".vector")
    np.save(vec_path, vec)
    data = json.loads(mem_path.read_text(encoding='utf-8'))
    data["embedding_ready"] = True
    data["embedding_model"] = EMBED_MODEL
    data["embedding_dim"] = int(vec.shape[0])
    mem_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
    return vec_path

def save_override(mem_path, new_owner, new_weights):
    data = json.loads(mem_path.read_text(encoding='utf-8'))
    data["curator"]["primary_owner"] = new_owner
    data["curator"]["weights"] = new_weights
    data["curator"]["override_at"] = datetime.datetime.datetime.utcnow().isoformat() + "Z"
    mem_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')

st.title("RAG Curator Dashboard")
st.sidebar.header("Controls")
memories = load_memories()
if not memories:
    st.warning("No memories found in " + str(MEMORIES_DIR))
    st.stop()
selected = st.sidebar.selectbox("Select Memory", [p.name for p in memories])
mem_path = MEMORIES_DIR / selected
data = json.loads(mem_path.read_text(encoding='utf-8'))

col1, col2 = st.columns([3,1])
with col1:
    st.subheader(f"Memory: {data.get('chunk_source')} [chunk {data.get('chunk_index')}]")
with col2:
    st.write(f"ID: {data.get('memory_id')[:8]}")
    st.write(f"Created: {data.get('created_at')}")
with st.expander("Raw Text", expanded=False):
    st.code(data.get('text','')[:2000] + ('...' if len(data.get('text',''))>2000 else ''), language='text')

if data.get('summary'):
    with st.expander('Summary', expanded=False):
        st.write(data['summary'])

st.subheader('Persona Analyses')
tabs = st.tabs(['archivist','formalist','synthesist','strategist'])
for tab,name in zip(tabs, ['archivist','formalist','synthesist','strategist']):
    with tab:
        out = data.get('curator',{}).get('persona_outputs',{}).get(name,{})
        if isinstance(out, dict) and out.get('_raw_output'):
            st.error('Parsing failed — raw:')
            st.code(out.get('_raw_output'))
        else:
            st.json(out)

st.subheader('Curator Debate Transcript')
debate = data.get('curator',{}).get('debate_log','')
if debate:
    st.text_area('Debate', debate, height=300)
else:
    st.info('No debate log available.')

st.subheader('Curator Decision')
owner = data.get('curator',{}).get('primary_owner','unknown')
weights = data.get('curator',{}).get('weights',{})
cols = st.columns(3)
cols[0].metric('Primary Owner', owner.title())
cols[1].metric('Top Weight', f"{max(weights.values()):.1%}" if weights else "N/A")
cols[2].metric('Rounds', data.get('curator',{}).get('decision',{}).get('rounds','?'))
st.json(weights)

st.subheader('Manual Override')
with st.form('override'):
    new_owner = st.selectbox('New owner', ['archivist','formalist','synthesist','strategist'], index=['archivist','formalist','synthesist','strategist'].index(owner) if owner in ['archivist','formalist','synthesist','strategist'] else 0)
    wcols = st.columns(4)
    new_weights = {}
    for i,k in enumerate(['archivist','formalist','synthesist','strategist']):
        with wcols[i]:
            new_weights[k] = st.number_input(k.title(), 0.0, 1.0, float(weights.get(k,0.25)), step=0.05, key=f'w_{k}')
    submit = st.form_submit_button('Apply')
    if submit:
        s = sum(new_weights.values())
        if abs(s-1.0)>0.01:
            st.error(f'Weights must sum to 1.0 (current {s:.3f})')
        else:
            data['curator']['primary_owner'] = new_owner
            data['curator']['weights'] = {k: round(v/s,3) for k,v in new_weights.items()}
            mem_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
            st.success('Override saved!')
            st.experimental_rerun()

st.subheader('Embedding')
if data.get('embedding_ready'):
    st.success(f"Embedded with {data.get('embedding_model')} ({data.get('embedding_dim')} dims)")
    if st.button('Re-embed'):
        embed_and_save(mem_path, data.get('text',''))
        st.success('Re-embedded')
else:
    if st.button('Generate embedding'):
        embed_and_save(mem_path, data.get('text',''))
        st.success('Embedded')
