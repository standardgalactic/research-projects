# RAG Multi-Persona Memory System

This repository contains a production-ready RAG memory pipeline with:
- Multi-persona analysis (Archivist, Formalist, Synthesist, Strategist)
- Curator arbitration with debate transcripts
- Embedding step (sentence-transformers) producing `.vector` files
- Streamlit dashboard for inspection and overrides
- Shell pipeline to process .txt files into `.memory` objects

See `docs/USAGE.md` for setup and running instructions.
