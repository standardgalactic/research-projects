#!/usr/bin/env python3
import argparse, json, numpy as np
from pathlib import Path
from sentence_transformers import SentenceTransformer
MODEL_NAME = "all-MiniLM-L6-v2"
def embed_text(text: str, model):
    return model.encode(text, convert_to_numpy=True, normalize_embeddings=True)
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("memory_dir")
    parser.add_argument("--model", default=MODEL_NAME)
    args = parser.parse_args()
    model = SentenceTransformer(args.model)
    mem_dir = Path(args.memory_dir)
    for mem_path in mem_dir.glob("*.memory"):
        data = json.loads(mem_path.read_text(encoding='utf-8'))
        txt = data.get("summary") or data.get("text","")
        if len(txt)>8000: txt = txt[:8000]
        vec = embed_text(txt, model)
        vec_path = mem_path.with_suffix(".vector")
        np.save(vec_path, vec)
        data["embedding_ready"] = True
        data["embedding_model"] = args.model
        data["embedding_dim"] = int(vec.shape[0])
        mem_path.write_text(json.dumps(data, indent=2, ensure_ascii=False), encoding='utf-8')
if __name__=='__main__':
    main()
