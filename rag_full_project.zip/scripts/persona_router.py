#!/usr/bin/env python3
"""Persona router with strict schema prompts and repair loop.

Calls Ollama via CLI: `ollama run <model> <prompt>` and passes chunk text on stdin.
Adjust OLLAMA_MODEL if your local tag differs.
"""
import subprocess, json, shlex, sys, os, re, textwrap, logging
logging.basicConfig(level=logging.INFO)

OLLAMA_MODEL = os.environ.get("OLLAMA_MODEL", "granite3.2:8b")

PERSONA_PROMPTS = {
    "archivist": """You are the Archivist (RAG-01). Preserve optionality, provenance, and contingent knowledge.
Return EXACTLY the following JSON (no markdown, no explanation):

{
  "keep": ["exact phrase or element to retain", "..."],
  "delete": ["element safe to discard", "..."],
  "tags": ["optionality","lineage","..."],
  "rationale": "short justification (<=120 chars)"
}

Example:
{
  "keep": ["2015 paper reference","dismissal rationale"],
  "delete": ["duplicate bullet points"],
  "tags": ["lineage","optionality"],
  "rationale": "Dismissed work may become relevant with new hardware."
}
""",
    "formalist": """You are the Formalist (RAG-02). Identify load-bearing axioms, definitions, and proof obligations.
Return EXACTLY this JSON:

{
  "keep": ["axiom or definition","..."],
  "delete": ["redundant derivation","..."],
  "compression_plan": "how to reconstruct deleted parts",
  "proof_obligations": ["derive X from Y","..."],
  "rationale": "short justification"
}

Example:
{
  "keep": ["symplectic transformation definition"],
  "delete": ["motivational preamble"],
  "compression_plan": "regenerate from stabilizer axioms",
  "proof_obligations": ["show preservation of error distance"],
  "rationale": "Only irreducible core needed."
}
""",
    "synthesist": """You are the Synthesist (RAG-03). Surface generative tensions, bridges, and open questions.
Return EXACTLY this JSON:

{
  "keep": ["conceptual tension","..."],
  "delete": ["closed fact","..."],
  "branches": ["what if X + Y?","..."],
  "fertility_score": 7.2,
  "rationale": "short justification"
}

Example:
{
  "keep": ["unexpected 12% reduction"],
  "delete": ["isolated metric"],
  "branches": ["combine with neural error mitigation?"],
  "fertility_score": 8.4,
  "rationale": "Opens hybrid-code family."
}
""",
    "strategist": """You are the Strategist (RAG-04). Extract levers, blockers, and next actions.
Return EXACTLY this JSON:

{
  "keep": ["bottleneck description","..."],
  "delete": ["philosophical aside","..."],
  "leverage_points": ["12% decoherence → scale threshold","..."],
  "next_action": "prototype hardware test",
  "traction_risk": "high",
  "rationale": "short justification"
}

Example:
{
  "keep": ["12% improvement","no hardware trial"],
  "delete": ["lineage discussion"],
  "leverage_points": ["enables 1000-qubit scaling"],
  "next_action": "low-cost hardware validation",
  "traction_risk": "high",
  "rationale": "Proof gap blocks adoption."
}
""",
}

def call_ollama(prompt: str, stdin_text: str) -> str:
    cmd = f"ollama run {shlex.quote(OLLAMA_MODEL)} {shlex.quote(prompt)}"
    proc = subprocess.run(cmd, input=stdin_text.encode('utf-8'), shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    if proc.returncode != 0:
        raise RuntimeError(f"Ollama error (rc={proc.returncode}): {proc.stderr.decode()}")
    return proc.stdout.decode('utf-8', errors='replace')

def extract_json(text: str) -> str:
    match = re.search(r"(\{(?:[^{}]|(?1))*\})", text, re.DOTALL)
    return match.group(1) if match else text

def repair_and_retry(persona: str, chunk_text: str, raw_output: str, attempts: int = 3) -> dict:
    for attempt in range(1, attempts+1):
        repair_prompt = textwrap.dedent(f"""The previous response was not valid JSON. Return ONLY the corrected JSON object.

Original output (truncated):
{raw_output[:500]}

Persona: {persona}
Required schema (copy exactly):
{PERSONA_PROMPTS[persona]}
""")
        repaired = call_ollama(repair_prompt, chunk_text)
        try:
            return json.loads(extract_json(repaired))
        except json.JSONDecodeError:
            raw_output = repaired
    return {"_raw_output": raw_output, "_repair_failed": True}

def analyze_with_persona(persona: str, chunk_text: str) -> dict:
    if persona not in PERSONA_PROMPTS:
        raise ValueError(f"Unknown persona: {persona}")
    prompt = PERSONA_PROMPTS[persona] + "\n\nMemory chunk:\n" 
    out = call_ollama(prompt, chunk_text)
    try:
        return json.loads(extract_json(out))
    except json.JSONDecodeError:
        return repair_and_retry(persona, chunk_text, out)

if __name__ == '__main__':
    if len(sys.argv) < 3:
        print("Usage: persona_router.py <persona> <chunk_file_or_->", file=sys.stderr); sys.exit(2)
    persona = sys.argv[1]
    target = sys.argv[2]
    if target == '-':
        chunk = sys.stdin.read()
    else:
        with open(target,'r',encoding='utf-8') as f:
            chunk = f.read()
    res = analyze_with_persona(persona, chunk)
    print(json.dumps(res, indent=2, ensure_ascii=False))
