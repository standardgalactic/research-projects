#!/usr/bin/env bash
set -euo pipefail
DIR="${1:-.}"
MEM_DIR="${DIR%/}/memories"
PROGRESS_FILE="${DIR%/}/progress.log"
SUMMARY_FILE="${DIR%/}/source-control.txt"
mkdir -p "$MEM_DIR"
touch "$PROGRESS_FILE" "$SUMMARY_FILE"
echo "Script started at $(date -u)" >> "$PROGRESS_FILE"
for file in "$DIR"/*.txt; do
  [ -f "$file" ] || continue
  base=$(basename "$file" .txt)
  if grep -Fxq "$base" "$PROGRESS_FILE" 2>/dev/null; then
    echo "Skipping $file (already processed)" >> "$PROGRESS_FILE"
    continue
  fi
  tmpdir=$(mktemp -d)
  split -l 282 "$file" "$tmpdir/chunk_"
  idx=0
  for chunk in "$tmpdir"/chunk_*; do
    idx=$((idx+1))
    memfile="${MEM_DIR}/${base}-${idx}.memory"
    echo "Processing $chunk -> $memfile" >> "$PROGRESS_FILE"
    # human summary
    echo "### ${base} - chunk ${idx}" >> "$SUMMARY_FILE"
    echo "" >> "$SUMMARY_FILE"
    if command -v ollama >/dev/null 2>&1; then
      ollama run granite3.2:8b "Summarize in detail and explain the main points:" < "$chunk" | tee -a "$SUMMARY_FILE"
    else
      head -n 40 "$chunk" >> "$SUMMARY_FILE"
    fi
    echo "" >> "$SUMMARY_FILE"
    # JSON summary attempt
    summary_json=""
    if command -v ollama >/dev/null 2>&1; then
      summary_json=$(ollama run granite3.2:8b "Summarize in one paragraph and return JSON exactly like {"summary":"..."}. Return only JSON." < "$chunk" 2>/dev/null || true)
    fi
    summary_text=""
    if echo "$summary_json" | jq -e . >/dev/null 2>&1; then
      summary_text=$(echo "$summary_json" | jq -r '.summary // ""')
    else
      summary_text=$(echo "$summary_json" | head -n 10)
    fi
    # curator processing
    curator_output=$(python3 "$(dirname "$0")/curator.py" "-" < "$chunk")
    created_at=$(date -u +"%Y-%m-%dT%H:%M:%SZ")
    uuid=$(python3 - <<'PY'
import uuid,sys
print(str(uuid.uuid4()))
PY
)
    chunk_json=$(python3 - <<'PY'
import json,sys
txt=sys.stdin.read()
print(json.dumps(txt))
PY
<<< "$(cat "$chunk")")
    cat > "$memfile" <<EOF
{
  "memory_id": "${uuid}",
  "chunk_source": "${base}.txt",
  "chunk_index": ${idx},
  "text": ${chunk_json},
  "summary": $(python3 - <<'PY'
import sys,json
s=sys.stdin.read()
s=s.strip()
if s=="":
    print(json.dumps(""))
else:
    try:
        import json as _j
        obj=_j.loads(s)
        if isinstance(obj, dict) and "summary" in obj:
            print(json.dumps(obj.get("summary","")))
        else:
            print(json.dumps(s))
    except Exception:
        print(json.dumps(s))
PY
<<< "$summary_json"),
  "persona_analysis": {},
  "curator": $(python3 - <<'PY'
import sys,json
s=sys.stdin.read()
try:
    obj=json.loads(s)
    out={}
    out['primary_owner']=obj.get('decision',{}).get('primary_owner')
    out['weights']=obj.get('decision',{}).get('weights',{})
    out['lifecycle']={'review_in_months':6,'prune_if_unused_after_months':12}
    out['drift_score']=0.0
    out['alerts']=[]
    out['debate_log']=obj.get('debate_log','')
    out['persona_outputs']=obj.get('persona_outputs',{})
    print(json.dumps(out, ensure_ascii=False))
except Exception as e:
    print(json.dumps({'_error': str(e), 'raw': s}))
PY
<<< "$curator_output"),
  "tags": [],
  "state_machine": {"state": "candidate", "reason": "initial processing"},
  "created_at": "${created_at}",
  "embedding_ready": false
}
EOF
    echo "Wrote $memfile" >> "$PROGRESS_FILE"
  done
  rm -rf "$tmpdir"
  echo "$base" >> "$PROGRESS_FILE"
done
# Optional embedding step
if python3 -c "import sentence_transformers" >/dev/null 2>&1; then
  python3 "$(dirname "$0")/embed_memory.py" "$MEM_DIR" || true
fi
echo "Completed at $(date -u)" >> "$PROGRESS_FILE"
