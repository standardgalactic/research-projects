#!/usr/bin/env bash
BLENDER_BIN="${BLENDER_BIN:-blender}"
OUTBASE="blender_runs"
TIMESTAMP=$(date +"%Y%m%d_%H%M%S")
LOGDIR="$OUTBASE/logs_$TIMESTAMP"
mkdir -p "$LOGDIR"
run_script() {
    local script="$1"; shift
    local args=("$@")
    local name=$(basename "$script" .py)
    local outdir="$OUTBASE/${name}_${TIMESTAMP}"
    mkdir -p "$outdir"
    local logfile="$LOGDIR/${name}.log"
    "$BLENDER_BIN" --background --python "$script" -- --output "$outdir" "${args[@]}" > "$logfile" 2>&1
}
if [[ "$@" == *"--"* ]]; then
    SCRIPTS=("${@%%--*}")
    FORWARDING="${*@#*-- }"
    FORWARD_ARR=($FORWARDING)
else
    SCRIPTS=("$@")
    FORWARD_ARR=()
fi
for script in "${SCRIPTS[@]}"; do
    run_script "$script" "${FORWARD_ARR[@]}"
done
