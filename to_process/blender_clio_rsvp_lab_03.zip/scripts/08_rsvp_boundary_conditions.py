import bpy
import argparse
import os
import random

def laplacian(field, mode="reflect"):
    rows = len(field)
    cols = len(field[0])
    out = [[0.0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            if mode == "periodic":
                up    = field[(i-1) % rows][j]
                down  = field[(i+1) % rows][j]
                left  = field[i][(j-1) % cols]
                right = field[i][(j+1) % cols]
                c = field[i][j]
            else:  # reflect / clamp
                c = field[i][j]
                up    = field[i-1][j] if i > 0 else c
                down  = field[i+1][j] if i < rows-1 else c
                left  = field[i][j-1] if j > 0 else c
                right = field[i][j+1] if j < cols-1 else c
            out[i][j] = up + down + left + right - 4*c
    return out

def grad_mag(field, mode="reflect"):
    rows = len(field)
    cols = len(field[0])
    out = [[0.0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            if mode == "periodic":
                up    = field[(i-1) % rows][j]
                down  = field[(i+1) % rows][j]
                left  = field[i][(j-1) % cols]
                right = field[i][(j+1) % cols]
            else:
                c = field[i][j]
                up    = field[i-1][j] if i > 0 else c
                down  = field[i+1][j] if i < rows-1 else c
                left  = field[i][j-1] if j > 0 else c
                right = field[i][j+1] if j < cols-1 else c
            gx = 0.5 * (right - left)
            gy = 0.5 * (down - up)
            out[i][j] = (gx*gx + gy*gy) ** 0.5
    return out

def update_rsvp(phi, v, S, params):
    dt = params["dt"]
    Dp = params["D_phi"]
    Dv = params["D_v"]
    Ds = params["D_S"]
    k_relax = params["k_relax"]
    gamma_v = params["gamma_v"]
    sigma_S = params["sigma_S"]
    k_S = params["k_S"]
    mode = params.get("boundary_mode", "reflect")

    L_phi = laplacian(phi, mode)
    L_v   = laplacian(v,   mode)
    L_S   = laplacian(S,   mode)

    grad_phi = grad_mag(phi, mode)
    grad_v   = grad_mag(v,   mode)

    rows = len(phi)
    cols = len(phi[0])
    phi_next = [[0.0]*cols for _ in range(rows)]
    v_next   = [[0.0]*cols for _ in range(rows)]
    S_next   = [[0.0]*cols for _ in range(rows)]

    for i in range(rows):
        for j in range(cols):
            p = phi[i][j]
            vv = v[i][j]
            ss = S[i][j]

            phi_next[i][j] = p + dt * (
                Dp * L_phi[i][j]
                - k_relax * ss * (p - 0.5)
                + 0.05 * (vv - p)
            )

            phi_grad_here = grad_phi[i][j]
            v_next[i][j] = vv + dt * (
                Dv * L_v[i][j]
                - gamma_v * vv
                + 0.2 * phi_grad_here
            )

            gv = grad_v[i][j]
            S_next[i][j] = ss + dt * (
                Ds * L_S[i][j]
                + sigma_S * (gv * gv)
                - k_S * (ss - 0.5)
            )

    return phi_next, v_next, S_next

def run_rsvp_sim(grid, steps, params, probe=False):
    def rand_field():
        return [[random.random() for _ in range(grid)] for _ in range(grid)]
    phi = rand_field()
    v   = rand_field()
    S   = rand_field()
    history = []
    energies = []
    mode = params.get("boundary_mode", "reflect")

    for t in range(steps):
        phi, v, S = update_rsvp(phi, v, S, params)

        flat_phi = [x for row in phi for x in row]
        flat_v   = [x for row in v   for x in row]
        flat_S   = [x for row in S   for x in row]

        def stats(flat):
            m = sum(flat) / len(flat)
            var = sum((x - m)**2 for x in flat) / len(flat)
            return m, var

        m_phi, var_phi = stats(flat_phi)
        m_v,   var_v   = stats(flat_v)
        m_S,   var_S   = stats(flat_S)
        history.append((t, m_phi, var_phi, m_v, var_v, m_S, var_S))

        if probe:
            gphi = grad_mag(phi, mode)
            rows = len(phi)
            cols = len(phi[0])
            acc = 0.0
            for i in range(rows):
                for j in range(cols):
                    gp = gphi[i][j]
                    vv = v[i][j]
                    ss = S[i][j]
                    acc += (gp*gp + vv*vv + (ss - 0.5)*(ss - 0.5))
            energies.append((t, acc / (rows*cols)))

    return history, energies

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
parser.add_argument('--size', type=int, default=36)
    parser.add_argument('--steps', type=int, default=90)
    parser.add_argument('--boundary_type', type=str, default='periodic')
    return parser.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.output, exist_ok=True)
    print("RSVP boundary conditions:", vars(args))

    grid = max(4, int(args.size))
    steps = max(1, int(args.steps))

    params = {
        "D_phi":  0.15,
        "D_v":    0.13,
        "D_S":    0.06,
        "dt":     0.08,
        "k_relax": 0.38,
        "gamma_v": 0.32,
        "sigma_S": 0.30,
        "k_S":     0.32,
    }
    params['boundary_mode'] = getattr(args, 'boundary_type', 'periodic')

    history, energies = run_rsvp_sim(grid, steps, params, probe=False)

    metrics_path = os.path.join(args.output, "metrics.txt")
    with open(metrics_path, "w", encoding="utf-8") as f:
        f.write("t\tm_phi\tvar_phi\tm_v\tvar_v\tm_S\tvar_S\n")
        for rec in history:
            line = "\t".join(str(x) for x in rec)
            f.write(line + "\n")

    if False and energies:
        energy_path = os.path.join(args.output, "energy.txt")
        with open(energy_path, "w", encoding="utf-8") as f:
            f.write("t\tenergy_density\n")
            for tt, ee in energies:
                f.write(str(tt) + "\t" + str(ee) + "\n")

    bpy.ops.wm.save_mainfile(filepath=os.path.join(args.output, "scene.blend"))

if __name__ == "__main__":
    main()
