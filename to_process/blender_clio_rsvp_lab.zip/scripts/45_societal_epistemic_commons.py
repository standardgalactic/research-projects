import bpy
import argparse
import os
import random
import math

def run_toy_process(num_units, steps, alpha, noise_scale):
    """Simple consensus-like toy dynamics with noise.
    Returns a list of (t, mean, variance).
    """
    state = [random.random() for _ in range(num_units)]
    history = []
    for t in range(steps):
        mean = sum(state) / len(state)
        new_state = []
        for x in state:
            dx = alpha * (mean - x) + noise_scale * (random.random() - 0.5)
            new_state.append(x + dx)
        state = new_state
        mean = sum(state) / len(state)
        var = sum((x - mean) ** 2 for x in state) / len(state)
        history.append((t, mean, var))
    return history

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
parser.add_argument('--agents', type=int, default=70)
    parser.add_argument('--resources', type=int, default=10)
    return parser.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.output, exist_ok=True)
    print("Societal epistemic commons:", vars(args))

    # Derive a toy system size and parameters from the arguments.
    num_units = max(4, int(args.agents + args.resources * 4))
    steps = max(1, int(100))
    alpha = float(0.09)
    noise_scale = float(0.03)

    history = run_toy_process(num_units, steps, alpha, noise_scale)

    # Write out a small metrics file so each script produces real data.
    metrics_path = os.path.join(args.output, "metrics.txt")
    with open(metrics_path, "w", encoding="utf-8") as f:
        f.write("t\tmean\tvariance\n")
        for t, mean, var in history:
            f.write(str(t) + "\t" + str(mean) + "\t" + str(var) + "\n")

    # Minimal Blender interaction: ensure a .blend is saved as a marker.
    bpy.ops.wm.save_mainfile(filepath=os.path.join(args.output, "scene.blend"))

if __name__ == "__main__":
    main()
