import bpy
import argparse
import os
import random

def laplacian(field):
    rows = len(field)
    cols = len(field[0])
    out = [[0.0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            c = field[i][j]
            up    = field[i-1][j] if i > 0 else c
            down  = field[i+1][j] if i < rows-1 else c
            left  = field[i][j-1] if j > 0 else c
            right = field[i][j+1] if j < cols-1 else c
            out[i][j] = up + down + left + right - 4*c
    return out

def grad_mag(field):
    rows = len(field)
    cols = len(field[0])
    out = [[0.0]*cols for _ in range(rows)]
    for i in range(rows):
        for j in range(cols):
            c = field[i][j]
            up    = field[i-1][j] if i > 0 else c
            down  = field[i+1][j] if i < rows-1 else c
            left  = field[i][j-1] if j > 0 else c
            right = field[i][j+1] if j < cols-1 else c
            gx = 0.5 * (right - left)
            gy = 0.5 * (down - up)
            out[i][j] = (gx*gx + gy*gy) ** 0.5
    return out

def update_rsvp(phi, v, S, params):
    dt = params["dt"]
    Dp = params["D_phi"]
    Dv = params["D_v"]
    Ds = params["D_S"]
    k_relax = params["k_relax"]
    gamma_v = params["gamma_v"]
    sigma_S = params["sigma_S"]
    k_S = params["k_S"]

    L_phi = laplacian(phi)
    L_v   = laplacian(v)
    L_S   = laplacian(S)

    grad_phi = grad_mag(phi)
    grad_v   = grad_mag(v)

    rows = len(phi)
    cols = len(phi[0])
    phi_next = [[0.0]*cols for _ in range(rows)]
    v_next   = [[0.0]*cols for _ in range(rows)]
    S_next   = [[0.0]*cols for _ in range(rows)]

    for i in range(rows):
        for j in range(cols):
            p = phi[i][j]
            vv = v[i][j]
            ss = S[i][j]

            # φ: diffusion + relaxation toward low entropy + weak tug from v
            phi_next[i][j] = p + dt * (
                Dp * L_phi[i][j]
                - k_relax * ss * (p - 0.5)
                + 0.05 * (vv - p)
            )

            # v: diffusion + decay + drive from ∇φ
            phi_grad_here = grad_phi[i][j]
            v_next[i][j] = vv + dt * (
                Dv * L_v[i][j]
                - gamma_v * vv
                + 0.2 * phi_grad_here
            )

            # S: diffusion + production from |∇v|^2 - relaxation to baseline
            gv = grad_v[i][j]
            S_next[i][j] = ss + dt * (
                Ds * L_S[i][j]
                + sigma_S * (gv * gv)
                - k_S * (ss - 0.5)
            )

    return phi_next, v_next, S_next

def run_rsvp_sim(grid, steps, params):
    def rand_field():
        return [[random.random() for _ in range(grid)] for _ in range(grid)]
    phi = rand_field()
    v   = rand_field()
    S   = rand_field()
    history = []
    for t in range(steps):
        phi, v, S = update_rsvp(phi, v, S, params)
        flat_phi = [x for row in phi for x in row]
        flat_v   = [x for row in v   for x in row]
        flat_S   = [x for row in S   for x in row]
        def stats(flat):
            m = sum(flat) / len(flat)
            var = sum((x - m)**2 for x in flat) / len(flat)
            return m, var
        m_phi, var_phi = stats(flat_phi)
        m_v,   var_v   = stats(flat_v)
        m_S,   var_S   = stats(flat_S)
        history.append((t, m_phi, var_phi, m_v, var_v, m_S, var_S))
    return history

def parse_args():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output', required=True)
parser.add_argument('--size', type=int, default=32)
    parser.add_argument('--steps', type=int, default=80)
    return parser.parse_args()

def main():
    args = parse_args()
    os.makedirs(args.output, exist_ok=True)
    print("RSVP Hamiltonian probe:", vars(args))

    grid = max(4, int(args.size))
    steps = max(1, int(args.steps))

    params = {
        "D_phi":  0.16,
        "D_v":    0.14,
        "D_S":    0.06,
        "dt":     0.08,
        "k_relax": 0.42,
        "gamma_v": 0.34,
        "sigma_S": 0.36,
        "k_S":     0.34,
    }

    history = run_rsvp_sim(grid, steps, params)

    metrics_path = os.path.join(args.output, "metrics.txt")
    with open(metrics_path, "w", encoding="utf-8") as f:
        f.write("t\tm_phi\tvar_phi\tm_v\tvar_v\tm_S\tvar_S\n")
        for rec in history:
            line = "\t".join(str(x) for x in rec)
            f.write(line + "\n")

    bpy.ops.wm.save_mainfile(filepath=os.path.join(args.output, "scene.blend"))

if __name__ == "__main__":
    main()
