package com.stargen;

import com.stargen.engine.GameLoop;

public class Main {
    public static void main(String[] args){
        GameLoop.main(args); // delegate to existing loop entry
    }
}
