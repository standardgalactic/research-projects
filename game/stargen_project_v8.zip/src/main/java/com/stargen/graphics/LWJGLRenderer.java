package com.stargen.graphics;

import com.stargen.math.Vector3D;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

public class LWJGLRenderer implements RendererBackend {
    private long window = 0;
    private int width = 960, height = 600;
    private boolean init = false;

    @Override
    public void init(){
        if (!GLFW.glfwInit()){
            System.err.println("[LWJGLRenderer] GLFW init failed; falling back to console.");
            return;
        }
        GLFW.glfwWindowHint(GLFW.GLFW_RESIZABLE, GLFW.GLFW_TRUE);
        window = GLFW.glfwCreateWindow(width, height, "StarGen — LWJGL", MemoryUtil.NULL, MemoryUtil.NULL);
        if (window == 0){
            System.err.println("[LWJGLRenderer] Window creation failed; fallback.");
            GLFW.glfwTerminate();
            return;
        }
        GLFW.glfwMakeContextCurrent(window);
        GL.createCapabilities();
        GLFW.glfwSwapInterval(1); // vsync
        init = true;
        System.out.println("[LWJGLRenderer] Initialized " + width + "x" + height);
    }

    @Override
    public void setCamera(Vector3D pos, Vector3D euler){
        // For now, we just clear color based on camera Z to hint motion.
        float hue = (float) (Math.sin(pos.z * 0.05) * 0.5 + 0.5);
        GL11.glClearColor(0.05f, 0.05f + 0.3f*hue, 0.1f, 1.0f);
    }

    @Override
    public void drawWorldTick(){
        if (!init) return;
        if (GLFW.glfwWindowShouldClose(window)){
            return;
        }
        GL11.glViewport(0, 0, width, height);
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        // Minimal starfield: draw points with deterministic positions
        GL11.glBegin(GL11.GL_POINTS);
        for (int i=0;i<256;i++){
            float x = (float)Math.sin(i*12.9898)*43758.5453f;
            float y = (float)Math.cos(i*78.233)*12345.6789f;
            x = (x - (float)Math.floor(x))*2f - 1f;
            y = (y - (float)Math.floor(y))*2f - 1f;
            GL11.glVertex2f(x, y);
        }
        GL11.glEnd();

        GLFW.glfwSwapBuffers(window);
        GLFW.glfwPollEvents();
    }

    @Override
    public void shutdown(){
        if (window!=0){
            GLFW.glfwDestroyWindow(window);
            GLFW.glfwTerminate();
        }
        init = false;
    }

    public boolean isOpen(){
        return init && !GLFW.glfwWindowShouldClose(window);
    }
}
