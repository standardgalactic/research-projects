package com.stargen.engine.entities.ai;
public enum AIState { IDLE, CHASE, ATTACK, EVADE }
