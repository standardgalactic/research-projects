package com.stargen.research;

import java.util.*;
import com.stargen.engine.simulation.WorldState;

public class TechScreen {
    public boolean visible=false;
    private final TechLogic logic; private final TechTree tree; private final WorldState world;
    public TechScreen(TechLogic l, TechTree t, WorldState w){ this.logic=l; this.tree=t; this.world=w; }
    public List<String> lines(){
        List<String> out=new ArrayList<>(); int i=1;
        for (Technology t: tree.all()) out.add(String.format("%d) %-24s %s", i++, t.name, t.unlocked ? "[UNLOCKED]" : ""));
        out.add("Press 1..9 to unlock, T toggles overlay."); return out;
    }
    public void tryUnlockByDigit(int digit){ logic.tryUnlock(tree, world, digit-1); }
}
