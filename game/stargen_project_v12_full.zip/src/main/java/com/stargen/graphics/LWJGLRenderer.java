package com.stargen.graphics;

import com.stargen.math.Vector3D;
import com.stargen.engine.simulation.WorldState;
import com.stargen.controls.InputHandler;
import com.stargen.missions.FieldBubbleMission;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

public class LWJGLRenderer implements RendererBackend {
    private long window=0; private int width=960, height=600;
    private boolean init=false;
    private WorldState world;
    private HUDRenderer hud;
    private final float[] bg = new float[]{0.05f,0.1f,0.12f,1f};
    private InputHandler input=null;
    private FieldBubbleMission bubble=null;

    public void setWorld(WorldState w){ this.world=w; }
    public void setHUD(HUDRenderer h){ this.hud=h; }
    public void setInput(InputHandler handler){ this.input=handler; }
    public void setBubble(FieldBubbleMission m){ this.bubble=m; }

    @Override public void init(){
        if (!GLFW.glfwInit()){ System.err.println("[GLFW] init failed"); return; }
        window = GLFW.glfwCreateWindow(width, height, "StarGen — LWJGL", MemoryUtil.NULL, MemoryUtil.NULL);
        if (window==0){ System.err.println("[GLFW] window failed"); GLFW.glfwTerminate(); return; }
        GLFW.glfwMakeContextCurrent(window); GL.createCapabilities(); GLFW.glfwSwapInterval(1);
        // Key callback → InputHandler
        GLFW.glfwSetKeyCallback(window, (win,key,scancode,action,mods)->{
            if (input==null) return;
            boolean down = action != GLFW.GLFW_RELEASE;
            if (key==GLFW.GLFW_KEY_W) input.setKey('W', down);
            if (key==GLFW.GLFW_KEY_S) input.setKey('S', down);
            if (key==GLFW.GLFW_KEY_A) input.setKey('A', down);
            if (key==GLFW.GLFW_KEY_D) input.setKey('D', down);
            if (key==GLFW.GLFW_KEY_Q) input.setKey('Q', down);
            if (key==GLFW.GLFW_KEY_E) input.setKey('E', down);
            if (key==GLFW.GLFW_KEY_SPACE && down) input.setKey(' ', true);
            if (key==GLFW.GLFW_KEY_M && down && bubble!=null) bubble.visualize = !bubble.visualize;
            if (key==GLFW.GLFW_KEY_ESCAPE && down) GLFW.glfwSetWindowShouldClose(window, true);
        });
        init=true;
    }

    @Override public boolean isOpen(){ return init && !GLFW.glfwWindowShouldClose(window); }

    @Override public void setCamera(Vector3D pos, Vector3D euler){
        if (world!=null){
            float R=world.getR(); float lam=world.getLambdaCoupling(); float S=world.getEntropy(); float phi=world.getPhi();
            bg[0] = 0.05f + Math.min(0.5f, S*0.03f);
            bg[1] = 0.1f + 0.2f*(lam%1f);
            bg[2] = 0.12f + 0.3f*Math.max(0.2f, Math.min(1.0f, 0.5f + R*0.3f));
        }
    }

    @Override public void drawWorldTick(){
        GL11.glViewport(0,0,width,height);
        GL11.glClearColor(bg[0],bg[1],bg[2],bg[3]);
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        // star points
        GL11.glBegin(GL11.GL_POINTS);
        for (int i=0;i<512;i++){
            float x=(float)Math.sin(i*12.9898)*43758.5453f;
            float y=(float)Math.cos(i*78.233 )*12345.6789f;
            x = (x - (float)Math.floor(x))*2f - 1f;
            y = (y - (float)Math.floor(y))*2f - 1f;
            GL11.glVertex2f(x,y);
        }
        GL11.glEnd();

        // Field bubble visualization
        if (bubble!=null && bubble.visualize){
            GL11.glColor4f(0.9f, 0.95f, 1f, 0.35f);
            GL11.glBegin(GL11.GL_LINE_LOOP);
            int seg=64;
            float r= bubble.radius();
            // project a circle in screen space (simple overlay approximation)
            for (int i=0;i<seg;i++){
                double a = 2*Math.PI*i/seg;
                float sx = (float)Math.cos(a)*r/20f; // scale down to screen units
                float sy = (float)Math.sin(a)*r/20f;
                GL11.glVertex2f(0.5f*sx, -0.3f+0.5f*sy);
            }
            GL11.glEnd();
        }

        if (hud!=null && world!=null) hud.draw(world, width, height);

        GLFW.glfwSwapBuffers(window);
        GLFW.glfwPollEvents();
    }

    @Override public void shutdown(){
        if (window!=0){ GLFW.glfwDestroyWindow(window); GLFW.glfwTerminate(); }
        init=false;
    }
}
