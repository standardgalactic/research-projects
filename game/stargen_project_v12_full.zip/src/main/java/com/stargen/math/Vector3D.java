package com.stargen.math;

public class Vector3D {
    public float x,y,z;
    public Vector3D(){ this(0,0,0); }
    public Vector3D(float x,float y,float z){ this.x=x; this.y=y; this.z=z; }
    public Vector3D add(Vector3D o){ return new Vector3D(x+o.x,y+o.y,z+o.z); }
    public Vector3D sub(Vector3D o){ return new Vector3D(x-o.x,y-o.y,z-o.z); }
    public Vector3D mult(float s){ return new Vector3D(x*s,y*s,z*s); }
    public Vector3D normalized(){
        float L=(float)Math.sqrt(x*x+y*y+z*z);
        if (L<=1e-6f) return new Vector3D(0,0,0);
        return new Vector3D(x/L,y/L,z/L);
    }
    public float distanceSquared(Vector3D o){
        float dx=x-o.x, dy=y-o.y, dz=z-o.z;
        return dx*dx+dy*dy+dz*dz;
    }
}
