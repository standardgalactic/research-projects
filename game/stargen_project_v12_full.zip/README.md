# StarGen v12 — RSVP 4X × 6DOF Engine (Prototype)

**What's new in v12**

- Real keyboard controls (`W/S` thrust, `A/D` yaw, `Q/E` roll, `Space` fire) via GLFW callback in the LWJGL backend.
- Broadphase physics grid + AABB/OBB collider scaffolding.
- Modular HUD backends: **NanoVG**, **Bitmap** fallback, **ImGui stub**.
- `FieldBubbleMission`: in-world RSVP bubble that reduces/increases **S** and draws a distortion overlay. Toggle with `M`.
- All prior RSVP systems kept: WorldState (Φ, S, λ, R), TechTree unlocks, Collision+Damage scaled by RSVP.

## Run

```bash
./gradlew run                     # Console mode (no window)
./gradlew run -Drenderer=lwjgl    # LWJGL window, keyboard controls, HUD overlay
# Optional HUD backend:
./gradlew run -Drenderer=lwjgl -Dhud=nanovg   # try NanoVG (if present at runtime)
./gradlew run -Drenderer=lwjgl -Dhud=bitmap   # bitmap fallback
./gradlew run -Drenderer=lwjgl -Dhud=imgui    # ImGui stub (no-op unless user adds bindings)
```

Controls: `W/S` forward/back, `A/D` yaw, `Q/E` roll, `Space` fire, `T` tech overlay, `M` field bubble toggle, `ESC` closes window.
