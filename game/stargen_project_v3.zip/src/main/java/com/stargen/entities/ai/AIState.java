package com.stargen.entities.ai;

public enum AIState {
    IDLE, CHASE, ATTACK, EVADE
}
