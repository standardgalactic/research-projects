package com.stargen.graphics;

import com.stargen.math.Vector3D;

public interface RendererBackend {
    void init();
    boolean isOpen();
    void setCamera(com.stargen.math.Vector3D pos, com.stargen.math.Vector3D euler);
    void drawWorldTick();
    void shutdown();
}
