package com.stargen.graphics;
import com.stargen.engine.simulation.WorldState;

public class HUDRendererImGui implements HUDRenderer {
    // Stub: users can add LWJGL-IMGUI dependency and flesh this out.
    @Override public void draw(WorldState w, int width, int height){
        // no-op stub
    }
}
