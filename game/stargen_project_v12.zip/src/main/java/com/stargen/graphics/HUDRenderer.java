package com.stargen.graphics;
import com.stargen.engine.simulation.WorldState;
public interface HUDRenderer {
    void draw(WorldState w, int width, int height);
}
