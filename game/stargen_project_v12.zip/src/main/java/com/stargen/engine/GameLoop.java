package com.stargen.engine;

import com.stargen.engine.simulation.WorldState;
import com.stargen.entities.PlayerShip;
import com.stargen.entities.Entity;
import com.stargen.entities.weapons.Projectile;
import com.stargen.controls.InputHandler;
import com.stargen.graphics.*;
import com.stargen.math.Vector3D;
import com.stargen.research.*;
import com.stargen.missions.*;

public class GameLoop {

    private final WorldState world = new WorldState(1.0f, 0.2f, 0.4f);
    private final PlayerShip player = new PlayerShip(new Vector3D(0,0,0), world);
    private final InputHandler input = new InputHandler(player);
    private final EntityManager em = new EntityManager();
    private final CollisionSystem collisions = new CollisionSystem(em, world);
    private final TechLogic techLogic = new TechLogic();
    private final TechTree techTree = new TechTree();
    private final TechScreen techScreen = new TechScreen(techLogic, techTree, world);
    private final FieldBubbleMission bubble = new FieldBubbleMission(new Vector3D(0,0,-10), 6f, 0.6f, player, world);

    private RendererBackend renderer=null;
    private HUDRenderer hud=null;
    private float fireCooldown=0f;
    private boolean running=true;

    public GameLoop(){
        em.add(player);
        bubble.start();

        String rend = System.getProperty("renderer","");
        if ("lwjgl".equalsIgnoreCase(rend)){
            LWJGLRenderer l = new LWJGLRenderer();
            l.setWorld(world);
            l.setInput(input);
            l.setBubble(bubble);
            String hudChoice = System.getProperty("hud","nanovg");
            if ("bitmap".equalsIgnoreCase(hudChoice)) hud = new HUDRendererBitmap();
            else if ("imgui".equalsIgnoreCase(hudChoice)) hud = new HUDRendererImGui();
            else hud = new HUDRendererNanoVG();
            l.setHUD(hud);
            l.init();
            renderer = l;
        }
    }

    public void run(){
        long last=System.nanoTime();
        while (running){
            long now=System.nanoTime();
            float dt=(now-last)/1_000_000_000.0f; last=now;

            input.process(dt);
            fireCooldown -= dt;
            if (renderer!=null && fireCooldown<=0f){
                // fire when SPACE pressed
                if (input.consumeFire()){
                    fireCooldown=0.5f;
                    em.add(new Projectile(player.getPosition(), new Vector3D(0,0,-1), 30f, 12f, 3.0f, player));
                }
            }

            for (Entity e: em.all()) e.update(dt);
            collisions.update(dt);
            em.all().removeIf(Entity::isExpired);
            world.tick(dt);
            bubble.tick(dt);

            if (renderer!=null){
                renderer.setCamera(player.getPosition(), player.getOrientation());
                renderer.drawWorldTick();
                if (!renderer.isOpen()) running=false;
            } else {
                // headless: lightweight sleep + console HUD every second (optional)
                try { Thread.sleep(16);} catch(InterruptedException ie){ Thread.currentThread().interrupt(); }
            }
        }
        if (renderer!=null) renderer.shutdown();
    }

    public static void main(String[] args){
        new GameLoop().run();
    }
}
