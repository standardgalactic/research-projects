package com.stargen.research;

import java.util.*;

public class TechTree {
    private final List<Technology> techs = new ArrayList<>();
    public TechTree(){
        techs.add(new Technology("Efficient Supply Routing", 0.02f, -0.01f, 0.01f));
        techs.add(new Technology("Adaptive AI Schedulers", 0.03f,  0.02f, -0.02f));
        techs.add(new Technology("Constitutional Safety",  -0.01f,-0.03f, 0.05f));
        techs.add(new Technology("Quantum Refinery",       0.05f,  0.01f, -0.03f));
    }
    public java.util.List<Technology> all(){ return techs; }
    public Technology byIndex(int i){ return (i>=0 && i<techs.size())? techs.get(i): null; }
}
