package com.stargen.research;

import com.stargen.engine.simulation.WorldState;

public class TechLogic {
    public boolean tryUnlock(TechTree tree, WorldState world, int idx){
        Technology t = tree.byIndex(idx);
        if (t==null || t.unlocked) return false;
        t.unlocked = true;
        world.adjustLambda(t.dLambda);
        world.adjustEntropy(t.dS);
        return true;
    }
}
