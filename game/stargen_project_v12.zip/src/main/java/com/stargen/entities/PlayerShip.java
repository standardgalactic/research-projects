package com.stargen.entities;

import com.stargen.math.Vector3D;
import com.stargen.engine.simulation.WorldState;

public class PlayerShip extends Entity implements Damageable {
    private final WorldState world;
    private final Health health = new Health(100f);
    private final float thrustPower = 10f;
    private final float rotationPower = 5f;
    private boolean thrusting=false;
    private Vector3D thrustDir=new Vector3D(0,0,-1);

    public PlayerShip(Vector3D start, WorldState world){
        super(start); this.world=world; this.radius=0.7f;
    }

    public void applyThrust(Vector3D dir){
        thrusting=true; thrustDir = dir.normalized();
    }
    public void stopThrust(){ thrusting=false; }

    public void yaw(float k){
        float S = world.getEntropy();
        float stab = Math.max(0.1f, 1.0f - S/10f);
        rotationVelocity.y += k*rotationPower*stab;
    }
    public void pitch(float k){
        float S = world.getEntropy();
        float stab = Math.max(0.1f, 1.0f - S/10f);
        rotationVelocity.x += k*rotationPower*stab;
    }
    public void roll(float k){
        float S = world.getEntropy();
        float stab = Math.max(0.1f, 1.0f - S/10f);
        rotationVelocity.z += k*rotationPower*stab;
    }

    @Override public void update(float dt){
        if (thrusting){
            float phi = world.getPhi();
            float eff = thrustPower*Math.max(0.1f, phi);
            velocity.x += thrustDir.x*eff*dt;
            velocity.y += thrustDir.y*eff*dt;
            velocity.z += thrustDir.z*eff*dt;
        }
        rotationVelocity.x *= 0.92f; rotationVelocity.y *= 0.92f; rotationVelocity.z *= 0.92f;
        super.update(dt);
    }

    @Override public void takeDamage(float amt){
        health.damage(amt);
        if (health.dead()) markExpired();
    }
    @Override public boolean isDead(){ return health.dead(); }
}
