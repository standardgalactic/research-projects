package com.stargen.entities.weapons;

import com.stargen.entities.Entity;
import com.stargen.math.Vector3D;

public class Projectile extends Entity {
    private final float damage;
    private float life;
    private final Entity owner;
    public Projectile(Vector3D start, Vector3D dir, float speed, float dmg, float lifespan, Entity owner){
        super(start); this.velocity = dir.normalized().mult(speed);
        this.damage=dmg; this.life=lifespan; this.owner=owner;
        this.radius=0.2f; this.linearDrag=1.0f;
    }
    @Override public void update(float dt){
        life -= dt; if (life<=0){ markExpired(); return; }
        super.update(dt);
    }
    public float getDamage(){ return damage; }
    public Entity getOwner(){ return owner; }
}
