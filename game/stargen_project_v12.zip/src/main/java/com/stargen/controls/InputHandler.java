package com.stargen.controls;

import java.util.concurrent.atomic.AtomicBoolean;
import com.stargen.entities.PlayerShip;
import com.stargen.math.Vector3D;

public class InputHandler {
    private final PlayerShip player;
    private final AtomicBoolean w=new AtomicBoolean(false), s=new AtomicBoolean(false),
        a=new AtomicBoolean(false), d=new AtomicBoolean(false),
        q=new AtomicBoolean(false), e=new AtomicBoolean(false),
        space=new AtomicBoolean(false);

    public InputHandler(PlayerShip p){ this.player=p; }

    public void setKey(int key, boolean down){
        switch(key){
            case 'W': w.set(down); break; case 'S': s.set(down); break;
            case 'A': a.set(down); break; case 'D': d.set(down); break;
            case 'Q': q.set(down); break; case 'E': e.set(down); break;
            case ' ': space.set(down); break;
        }
    }

    public boolean consumeFire(){ return space.getAndSet(false); }

    public void process(float dt){
        if (w.get()) player.applyThrust(new Vector3D(0,0,-1));
        else if (s.get()) player.applyThrust(new Vector3D(0,0, 1));
        else player.stopThrust();

        if (a.get()) player.yaw(-1.0f);
        if (d.get()) player.yaw( 1.0f);
        if (q.get()) player.roll(-1.0f);
        if (e.get()) player.roll( 1.0f);
    }
}
