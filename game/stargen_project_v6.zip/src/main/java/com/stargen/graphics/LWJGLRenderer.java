package com.stargen.graphics;

import com.stargen.math.Vector3D;

public class LWJGLRenderer implements RendererBackend {
    private boolean initialized = false;
    @Override public void init(){
        System.out.println("[LWJGLRenderer] LWJGL backend placeholder initialized (no GLFW/GL until deps enabled).");
        initialized = true;
    }
    @Override public void setCamera(Vector3D pos, Vector3D euler){ /* would set view matrices */ }
    @Override public void drawWorldTick(){ if (!initialized) return; /* would draw points/lines */ }
    @Override public void shutdown(){ System.out.println("[LWJGLRenderer] shutdown"); }
}
