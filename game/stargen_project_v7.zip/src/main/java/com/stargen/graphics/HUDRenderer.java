package com.stargen.graphics;

import com.stargen.engine.simulation.WorldState;

public class HUDRenderer {
    public void draw(WorldState w){
        float phi = w.getPhi();
        float S = w.getEntropy();
        float lam = w.getLambdaCoupling();
        float R = w.getR();
        System.out.printf("[HUD] Φ=%.3f  S=%.3f  λ=%.3f  R=%.3f%n", phi, S, lam, R);
    }
}
