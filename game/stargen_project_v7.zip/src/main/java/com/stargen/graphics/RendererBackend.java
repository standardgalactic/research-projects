package com.stargen.graphics;

import com.stargen.math.Vector3D;

public interface RendererBackend {
    void init();
    void setCamera(Vector3D pos, Vector3D euler);
    void drawWorldTick();
    void shutdown();
}
