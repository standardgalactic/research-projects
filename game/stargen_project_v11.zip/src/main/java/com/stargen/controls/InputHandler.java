package com.stargen.controls;

import com.stargen.entities.PlayerShip;
import com.stargen.math.Vector3D;
import java.util.concurrent.atomic.AtomicBoolean;

public class InputHandler {

    private final PlayerShip player;
    private final AtomicBoolean firePressed = new AtomicBoolean(false);

    public InputHandler(PlayerShip p){ this.player = p; }

    public void processInput(float dt){
        // placeholder: auto-thrust forward lightly
        player.applyThrust(new Vector3D(0,0,-1));
        // no real key polling here; GameLoop may set fire externally for the demo
    }

    public void setFire(boolean state){ firePressed.set(state); }
    public boolean consumeFire(){
        return firePressed.getAndSet(false);
    }
}
