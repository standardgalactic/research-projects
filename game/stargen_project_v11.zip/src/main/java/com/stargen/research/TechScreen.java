package com.stargen.research;

import java.util.*;
import com.stargen.engine.simulation.WorldState;

public class TechScreen {
    public boolean visible=false;
    private final TechLogic logic;
    private final TechTree tree;
    private final WorldState world;

    public TechScreen(TechLogic logic, TechTree tree, WorldState world){
        this.logic=logic; this.tree=tree; this.world=world;
    }

    public List<String> lines(){
        List<String> ls = new ArrayList<>();
        int idx=1;
        for (Technology t: tree.all()){
            ls.add(String.format("%d) %-24s  %s", idx, t.name, t.unlocked ? "[UNLOCKED]" : ""));
            idx++;
        }
        ls.add("Press 1..9 to unlock, ESC closes.");
        return ls;
    }

    public void tryUnlockIndex(int oneBased){
        int i=1;
        for (Technology t: tree.all()){
            if (i==oneBased){
                logic.tryUnlock(tree, world, t.name);
                break;
            }
            i++;
        }
    }
}
