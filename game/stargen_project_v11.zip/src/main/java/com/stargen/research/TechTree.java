package com.stargen.research;

import java.util.*;

public class TechTree {
    private final List<Technology> techs = new ArrayList<>();
    public TechTree(){
        techs.add(new Technology("Efficient Supply Routing", 0.02f, -0.01f, 0.01f));   // #1
        techs.add(new Technology("Adaptive AI Schedulers",  0.03f,  0.02f,-0.02f));   // #2
        techs.add(new Technology("Constitutional Safety",   -0.01f, -0.03f, 0.05f));  // #3
        techs.add(new Technology("Quantum Refinery",        0.05f,  0.01f,-0.03f));   // #4
    }
    public List<Technology> all(){ return techs; }
    public Technology byName(String n){
        for (Technology t: techs) if (t.name.equals(n)) return t;
        return null;
    }
}
