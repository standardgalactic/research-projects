package com.stargen.engine;

import java.util.*;
import com.stargen.entities.Entity;

public class EntityManager {
    private final List<Entity> entities = new ArrayList<>();
    public void add(Entity e){ entities.add(e); }
    public void remove(Entity e){ entities.remove(e); }
    public List<Entity> all(){ return entities; }
}
