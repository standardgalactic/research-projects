package com.stargen.engine;

import com.stargen.engine.simulation.WorldState;
import com.stargen.entities.PlayerShip;
import com.stargen.entities.Entity;
import com.stargen.entities.weapons.Projectile;
import com.stargen.controls.InputHandler;
import com.stargen.graphics.HUDRenderer;
import com.stargen.graphics.RendererBackend;
import com.stargen.graphics.LWJGLRenderer;
import com.stargen.math.Vector3D;
import com.stargen.research.*;
import com.stargen.missions.*;

public class GameLoop {

    private WorldState world;
    private PlayerShip player;
    private InputHandler input;
    private boolean running = true;

    private final HUDRenderer hud = new HUDRenderer();
    private float hudTimer=0f;

    private final EntityManager em = new EntityManager();
    private CollisionSystem collisions;

    private RendererBackend renderer = null;
    private final TechLogic techLogic = new TechLogic();
    private final TechTree techTree = new TechTree();
    private TechScreen techScreen;
    private Mission mission;

    private float fireCooldown = 0f;

    public GameLoop(){
        this.world = new WorldState(1.0f, 0.2f, 0.4f);
        this.player = new PlayerShip(new Vector3D(0,0,0), world);
        this.input = new InputHandler(player);
        this.collisions = new CollisionSystem(em, world);
        this.techScreen = new TechScreen(techLogic, techTree, world);

        // Entity registration
        em.add(player);

        // Mission region near (0,0,-10), radius 6, reducing entropy inside, unlock "Efficient Supply Routing"
        this.mission = new TechMission(new Vector3D(0,0,-10), 6f, 0.6f,
            "Efficient Supply Routing", player, world, techLogic, techTree);
        mission.start();

        // Renderer
        if ("lwjgl".equalsIgnoreCase(System.getProperty("renderer", ""))){
            LWJGLRenderer l = new LWJGLRenderer();
            l.init();
            l.setWorld(world);
            l.setTechScreen(techScreen);
            renderer = l;
        }
    }

    public void run(){
        long last = System.nanoTime();
        while (running){
            long now = System.nanoTime();
            float dt = (now - last)/1_000_000_000.0f;
            last = now;

            // Basic input + RSVP coupling on the ship already
            input.processInput(dt);

            // Fire projectile every 0.5s for demo
            fireCooldown -= dt;
            if (fireCooldown <= 0f){
                fireCooldown = 0.5f;
                Projectile p = new Projectile(player.getPosition(), new Vector3D(0,0,-1), 30f, 12f, 3.0f, player);
                em.add(p);
            }

            // Update entities
            for (Entity e: em.all()){
                e.update(dt);
            }

            // Collisions
            collisions.update(dt);

            // Despawn expired entities
            em.all().removeIf(Entity::isExpired);

            // RSVP global tick
            world.tick(dt);

            // Mission
            mission.tick(dt);

            // HUD console at 1 Hz
            hudTimer += dt;
            if (hudTimer >= 1.0f){
                hud.draw(world);
                hudTimer = 0f;
            }

            // Render
            if (renderer != null){
                renderer.setCamera(player.getPosition(), player.getOrientation());
                renderer.drawWorldTick();
            }

            try { Thread.sleep(16); } catch(InterruptedException ie){ Thread.currentThread().interrupt(); }
        }
        if (renderer != null) renderer.shutdown();
    }

    public static void main(String[] args){
        new GameLoop().run();
    }
}
