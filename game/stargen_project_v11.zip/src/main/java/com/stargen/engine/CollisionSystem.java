package com.stargen.engine;

import java.util.*;
import com.stargen.entities.Entity;
import com.stargen.entities.Damageable;
import com.stargen.entities.weapons.Projectile;
import com.stargen.math.Vector3D;
import com.stargen.engine.simulation.WorldState;

public class CollisionSystem {

    private final EntityManager em;
    private final WorldState world;

    public CollisionSystem(EntityManager em, WorldState world){
        this.em = em;
        this.world = world;
    }

    public void update(float dt){
        List<Entity> list = new ArrayList<>(em.all());
        int n = list.size();
        for (int i=0;i<n;i++){
            Entity a = list.get(i);
            for (int j=i+1;j<n;j++){
                Entity b = list.get(j);
                float r = a.getRadius() + b.getRadius();
                if (a.getPosition().distanceSquared(b.getPosition()) <= r*r){
                    handle(a,b);
                }
            }
        }
    }

    private void handle(Entity a, Entity b){
        // RSVP-scaled damage: higher entropy S amplifies friendly-fire and chaos; low Φ reduces effective mitigation
        float S = world.getEntropy();
        float Phi = world.getPhi();
        float instability = Math.max(0.5f, Math.min(2.0f, 1.0f + 0.1f*S));
        float mitigation = Math.max(0.4f, Math.min(1.0f, Phi)); // low Phi -> less mitigation (closer to 0.4)

        if (a instanceof Projectile && b instanceof Damageable){
            Projectile p = (Projectile)a;
            Damageable d = (Damageable)b;
            float dmg = p.getDamage() * instability * (1.1f - 0.1f*mitigation);
            d.takeDamage(dmg);
            p.markExpired();
        } else if (b instanceof Projectile && a instanceof Damageable){
            Projectile p = (Projectile)b;
            Damageable d = (Damageable)a;
            float dmg = p.getDamage() * instability * (1.1f - 0.1f*mitigation);
            d.takeDamage(dmg);
            p.markExpired();
        }
    }
}
