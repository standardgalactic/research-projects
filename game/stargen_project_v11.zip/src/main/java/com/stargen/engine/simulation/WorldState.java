package com.stargen.engine.simulation;

public class WorldState {
    private float phi, entropy, lambda, R, sigmaDot;
    private float productionRate = 0.01f;
    private float dissipationRate = 0.005f;
    private float noiseLevel = 0.002f;

    public WorldState(float phiInit, float sInit, float lambdaInit){
        this.phi = phiInit;
        this.entropy = sInit;
        this.lambda = lambdaInit;
        updateR();
    }

    private void updateR(){
        this.R = phi - lambda * entropy;
        this.sigmaDot = (productionRate - dissipationRate) + noiseLevel;
    }

    public void tick(float dt){
        phi += productionRate * dt * Math.max(0.1f, R);
        entropy += (sigmaDot + noiseLevel) * dt;
        updateR();
        if (R < 0.05f){
            entropy += 0.02f * dt;
            phi *= 0.99f;
        }
        if (entropy > 10f) entropy = 10f;
        if (phi < 0) phi = 0;
    }

    public float getPhi(){ return phi; }
    public float getEntropy(){ return entropy; }
    public float getLambdaCoupling(){ return lambda; }
    public float getR(){ return R; }
    public void adjustLambda(float d){ lambda = Math.max(0f, Math.min(1.5f, lambda+d)); updateR(); }
    public void adjustEntropy(float d){ entropy = Math.max(0f, Math.min(10f, entropy+d)); updateR(); }
}
