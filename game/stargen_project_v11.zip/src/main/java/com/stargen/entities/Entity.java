package com.stargen.entities;

import com.stargen.math.Vector3D;

public class Entity {
    protected Vector3D position = new Vector3D(0,0,0);
    protected Vector3D velocity = new Vector3D(0,0,0);
    protected Vector3D orientation = new Vector3D(0,0,0);
    protected Vector3D rotationVelocity = new Vector3D(0,0,0);
    protected float mass = 1.0f;
    protected float linearDrag = 0.98f;
    protected float radius = 0.5f;
    protected boolean expired = false;

    public Entity(){}
    public Entity(Vector3D p){ this.position = p; }

    public void update(float dt){
        velocity.x *= linearDrag;
        velocity.y *= linearDrag;
        velocity.z *= linearDrag;
        position.x += velocity.x * dt;
        position.y += velocity.y * dt;
        position.z += velocity.z * dt;
        orientation.x += rotationVelocity.x * dt;
        orientation.y += rotationVelocity.y * dt;
        orientation.z += rotationVelocity.z * dt;
    }

    public Vector3D getPosition(){ return position; }
    public Vector3D getOrientation(){ return orientation; }
    public float getRadius(){ return radius; }
    public boolean isExpired(){ return expired; }
    public void markExpired(){ expired = true; }
}
