package com.stargen.entities;

import com.stargen.math.Vector3D;
import com.stargen.engine.simulation.WorldState;

public class PlayerShip extends Entity implements Damageable {

    private final float thrustPower = 10.0f;
    private final float rotationPower = 5.0f;
    private Vector3D currentThrust = new Vector3D(0,0,0);
    private boolean thrusting = false;
    private final WorldState world;
    private final Health health = new Health(100f);

    public PlayerShip(Vector3D pos, WorldState world){
        super(pos);
        this.world = world;
        this.radius = 0.7f;
    }

    public void applyThrust(Vector3D dir){
        float phi = world.getPhi();
        float effective = thrustPower * Math.max(0.1f, phi);
        Vector3D d = dir.normalized().mult(effective);
        currentThrust = d;
        thrusting = true;
    }
    public void stopThrust(){ thrusting = false; }

    public void roll(float k){
        float S = world.getEntropy();
        float stab = Math.max(0.1f, 1.0f - S/10f);
        rotationVelocity.z += k * rotationPower * stab;
    }
    public void pitch(float k){
        float S = world.getEntropy();
        float stab = Math.max(0.1f, 1.0f - S/10f);
        rotationVelocity.x += k * rotationPower * stab;
    }
    public void yaw(float k){
        float S = world.getEntropy();
        float stab = Math.max(0.1f, 1.0f - S/10f);
        rotationVelocity.y += k * rotationPower * stab;
    }

    @Override public void update(float dt){
        if (thrusting){
            velocity.x += currentThrust.x * dt;
            velocity.y += currentThrust.y * dt;
            velocity.z += currentThrust.z * dt;
        }
        // rotational drag
        rotationVelocity.x *= 0.92f;
        rotationVelocity.y *= 0.92f;
        rotationVelocity.z *= 0.92f;
        super.update(dt);
    }

    @Override public void takeDamage(float amount){
        health.damage(amount);
        if (health.dead()){
            markExpired();
        }
    }

    @Override public boolean isDead(){ return health.dead(); }

    public Vector3D getPosition(){ return position; }
    public Vector3D getOrientation(){ return orientation; }
}
