package com.stargen.entities;

public interface Damageable {
    void takeDamage(float amount);
    boolean isDead();
}
