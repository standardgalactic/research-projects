package com.stargen.graphics;

import com.stargen.math.Vector3D;
import com.stargen.engine.simulation.WorldState;
import com.stargen.research.TechScreen;
import org.lwjgl.glfw.GLFW;
import org.lwjgl.opengl.GL;
import org.lwjgl.opengl.GL11;
import org.lwjgl.system.MemoryUtil;

import java.util.List;

public class LWJGLRenderer implements RendererBackend {
    private long window=0;
    private int width=960, height=600;
    private boolean init=false;
    private WorldState world;
    private TechScreen techScreen;
    private NanoVGOverlay nano = new NanoVGOverlay();

    public void setWorld(WorldState w){ this.world=w; }
    public void setTechScreen(TechScreen t){ this.techScreen=t; }

    @Override public void init(){
        if (!GLFW.glfwInit()){
            System.err.println("[LWJGL] GLFW init failed.");
            return;
        }
        window = GLFW.glfwCreateWindow(width, height, "StarGen — LWJGL", MemoryUtil.NULL, MemoryUtil.NULL);
        if (window==0){ System.err.println("[LWJGL] Window failed."); GLFW.glfwTerminate(); return; }
        GLFW.glfwMakeContextCurrent(window);
        GL.createCapabilities();
        GLFW.glfwSwapInterval(1);
        init = true;
        // Try NanoVG
        nano.init(width, height);
        System.out.println("[LWJGL] Initialized; NanoVG available=" + nano.isAvailable());
    }

    private float hueShift=0f;

    @Override public void setCamera(Vector3D pos, Vector3D euler){
        if (world != null){
            float phi = world.getPhi();
            float S   = world.getEntropy();
            float lam = world.getLambdaCoupling();
            float R   = world.getR();
            hueShift = lam;
            float pointSize = 1.5f + Math.min(6f, phi*2f);
            GL11.glPointSize(pointSize);
            float brightness = Math.max(0.2f, Math.min(1.0f, 0.5f + R*0.3f));
            float jitter = Math.min(0.5f, S * 0.03f);
            GL11.glClearColor(0.05f + jitter, 0.05f + 0.2f*(lam%1f), 0.1f + 0.3f*brightness, 1.0f);
        } else {
            GL11.glClearColor(0.05f, 0.1f, 0.12f, 1.0f);
        }
    }

    @Override public void drawWorldTick(){
        if (!init) return;
        if (GLFW.glfwWindowShouldClose(window)) return;

        GL11.glViewport(0, 0, width, height);
        GL11.glClear(GL11.GL_COLOR_BUFFER_BIT | GL11.GL_DEPTH_BUFFER_BIT);

        // starfield
        GL11.glBegin(GL11.GL_POINTS);
        for (int i=0;i<512;i++){
            float x = (float)Math.sin(i*12.9898 + hueShift)*43758.5453f;
            float y = (float)Math.cos(i*78.233  + hueShift)*12345.6789f;
            x = (x - (float)Math.floor(x))*2f - 1f;
            y = (y - (float)Math.floor(y))*2f - 1f;
            GL11.glVertex2f(x, y);
        }
        GL11.glEnd();

        // Overlay (NanoVG preferred)
        if (world != null){
            if (nano.isAvailable()){
                nano.beginFrame();
                nano.drawPanel(12, height-80, 400, 60, 0f,0f,0f,0.5f);
                String line = String.format("Φ=%5.2f  S=%5.2f  λ=%4.2f  R=%5.2f", world.getPhi(), world.getEntropy(), world.getLambdaCoupling(), world.getR());
                nano.drawText(24, height-45, line, 0.85f,0.98f,1f,1f);
                nano.endFrame();
            } else {
                // fallback tiny bitmap via GL quads (kept minimal)
                // Intentionally omitted here to keep file short, NanoVG is primary in v11.
            }
        }

        if (techScreen != null){
            if (GLFW.glfwGetKey(window, GLFW.GLFW_KEY_T) == GLFW.GLFW_PRESS){
                techScreen.visible = true;
            }
        }

        GLFW.glfwSwapBuffers(window);
        GLFW.glfwPollEvents();
    }

    @Override public void shutdown(){
        if (window!=0){ GLFW.glfwDestroyWindow(window); GLFW.glfwTerminate(); }
        init=false;
    }

    @Override public boolean isOpen(){ return init && !GLFW.glfwWindowShouldClose(window); }
}
