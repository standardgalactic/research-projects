package com.stargen.graphics;

import com.stargen.engine.simulation.WorldState;

public class HUDRenderer {
    public void draw(WorldState w){
        System.out.printf("[HUD] Φ=%.2f S=%.2f λ=%.2f R=%.2f%n",
            w.getPhi(), w.getEntropy(), w.getLambdaCoupling(), w.getR());
    }
}
