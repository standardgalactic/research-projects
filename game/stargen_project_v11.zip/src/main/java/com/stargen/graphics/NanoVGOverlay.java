package com.stargen.graphics;

import java.lang.reflect.*;
import java.nio.ByteBuffer;
import java.util.Objects;

/**
 * Reflection-based NanoVG overlay. If NanoVG classes are present on the classpath
 * (org.lwjgl.nanovg.NanoVG), this draws crisp HUD text; otherwise it no-ops.
 */
public class NanoVGOverlay {

    private Object vg = null;         // long context stored as a boxed Long via reflection
    private Method nvgBeginFrame, nvgEndFrame, nvgBeginPath, nvgRect, nvgFillColor, nvgFill, nvgText, nvgCreate, nvgRGBAf;
    private Method nvgCreateFontMem;
    private boolean available = false;
    private int width, height;

    public boolean isAvailable(){ return available; }

    public void init(int width, int height){
        this.width = width;
        this.height = height;
        try {
            Class<?> NVG = Class.forName("org.lwjgl.nanovg.NanoVG");
            Class<?> NVGColor = Class.forName("org.lwjgl.nanovg.NVGColor");
            nvgCreate = NVG.getMethod("nvgCreate", int.class);
            nvgBeginFrame = NVG.getMethod("nvgBeginFrame", long.class, int.class, int.class, float.class);
            nvgEndFrame = NVG.getMethod("nvgEndFrame", long.class);
            nvgBeginPath = NVG.getMethod("nvgBeginPath", long.class);
            nvgRect = NVG.getMethod("nvgRect", long.class, float.class, float.class, float.class, float.class);
            nvgFillColor = NVG.getMethod("nvgFillColor", long.class, NVGColor);
            nvgFill = NVG.getMethod("nvgFill", long.class);
            nvgText = NVG.getMethod("nvgText", long.class, float.class, float.class, CharSequence.class);
            nvgRGBAf = NVGColor.getMethod("create");
            nvgCreateFontMem = NVG.getMethod("nvgCreateFontMem", long.class, CharSequence.class, ByteBuffer.class, int.class, int.class);
            // flags: ANTI_ALIAS (1) | STENCIL_STROKES (2)
            vg = nvgCreate.invoke(null, 1 | 2);
            available = vg != null;
        } catch (Throwable t){
            available = false;
        }
    }

    public void beginFrame(){
        if (!available) return;
        try {
            long ctx = ((Number)vg).longValue();
            nvgBeginFrame.invoke(null, ctx, width, height, 1.0f);
        } catch(Throwable ignore){}
    }

    public void endFrame(){
        if (!available) return;
        try {
            long ctx = ((Number)vg).longValue();
            nvgEndFrame.invoke(null, ctx);
        } catch(Throwable ignore){}
    }

    public void drawPanel(float x, float y, float w, float h, float r, float g, float b, float a){
        if (!available) return;
        try {
            Class<?> NVGColor = Class.forName("org.lwjgl.nanovg.NVGColor");
            long ctx = ((Number)vg).longValue();
            Object color = NVGColor.getMethod("create").invoke(null);
            // set rgba
            NVGColor.getMethod("r", NVGColor, float.class).invoke(null, color, r);
            NVGColor.getMethod("g", NVGColor, float.class).invoke(null, color, g);
            NVGColor.getMethod("b", NVGColor, float.class).invoke(null, color, b);
            NVGColor.getMethod("a", NVGColor, float.class).invoke(null, color, a);

            nvgBeginPath.invoke(null, ctx);
            nvgRect.invoke(null, ctx, x, y, w, h);
            nvgFillColor.invoke(null, ctx, color);
            nvgFill.invoke(null, ctx);
        } catch(Throwable ignore){}
    }

    public void drawText(float x, float y, String text, float r, float g, float b, float a){
        if (!available) return;
        try {
            Class<?> NVGColor = Class.forName("org.lwjgl.nanovg.NVGColor");
            long ctx = ((Number)vg).longValue();
            Object color = NVGColor.getMethod("create").invoke(null);
            NVGColor.getMethod("r", NVGColor, float.class).invoke(null, color, r);
            NVGColor.getMethod("g", NVGColor, float.class).invoke(null, color, g);
            NVGColor.getMethod("b", NVGColor, float.class).invoke(null, color, b);
            NVGColor.getMethod("a", NVGColor, float.class).invoke(null, color, a);
            nvgFillColor.invoke(null, ctx, color);
            nvgText.invoke(null, ctx, x, y, text);
        } catch(Throwable ignore){}
    }
}
