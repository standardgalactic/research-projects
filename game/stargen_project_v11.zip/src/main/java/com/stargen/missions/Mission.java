package com.stargen.missions;

public abstract class Mission {
    public enum State { INACTIVE, ACTIVE, COMPLETE, FAILED }
    protected State state = State.INACTIVE;
    public State state(){ return state; }
    public void start(){ state = State.ACTIVE; }
    public abstract void tick(float dt);
}
