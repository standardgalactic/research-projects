package com.stargen.missions;

import com.stargen.engine.simulation.WorldState;
import com.stargen.entities.PlayerShip;
import com.stargen.math.Vector3D;
import com.stargen.research.TechLogic;
import com.stargen.research.TechTree;

public class TechMission extends Mission {

    private final Vector3D center;
    private final float radius;
    private final float entropyDeltaPerSec;
    private final String techToUnlock;
    private final PlayerShip player;
    private final WorldState world;
    private final TechLogic logic;
    private final TechTree tree;

    private float timer = 0f;
    private boolean unlocked=false;

    public TechMission(Vector3D center, float radius, float entropyDeltaPerSec,
                       String techToUnlock, PlayerShip player, WorldState world,
                       TechLogic logic, TechTree tree){
        this.center=center; this.radius=radius;
        this.entropyDeltaPerSec=entropyDeltaPerSec;
        this.techToUnlock=techToUnlock;
        this.player=player; this.world=world; this.logic=logic; this.tree=tree;
    }

    @Override public void tick(float dt){
        if (state != State.ACTIVE) return;
        // local effect: if player is inside region, reduce entropy; else, increase slightly
        float d2 = player.getPosition().distanceSquared(center);
        if (d2 <= radius*radius){
            world.adjustEntropy(-entropyDeltaPerSec * dt);
        } else {
            world.adjustEntropy(0.25f * entropyDeltaPerSec * dt);
        }
        // Objective: linger inside region for 10 seconds, then unlock tech
        if (d2 <= radius*radius){
            timer += dt;
            if (timer >= 10f && !unlocked){
                logic.tryUnlock(tree, world, techToUnlock);
                unlocked = true;
                state = State.COMPLETE;
            }
        } else {
            timer = Math.max(0f, timer - 0.5f*dt);
        }
    }
}
