package com.stargen.graphics;

/**
 * Placeholder for a future NanoVG-backed overlay renderer.
 * If you want crisp vector text, integrate LWJGL's NanoVG bindings and
 * port HUD/TechScreen text rendering here.
 */
public class NanoVGOverlayTODO {
    // TODO: integrate NanoVG (org.lwjgl.nanovg.NanoVG) and replace bitmap quads.
}
