"""Entropy Ecology Simulator package."""
