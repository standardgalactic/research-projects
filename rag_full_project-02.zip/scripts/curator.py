#!/usr/bin/env python3
import subprocess, json, sys, os, datetime, logging
logging.basicConfig(level=logging.INFO)
BASE_DIR = os.path.dirname(__file__)
PERSONA_ROUTER = os.path.join(BASE_DIR, "persona_router.py")
PERSONAS = ["archivist","formalist","synthesist","strategist"]
MAX_ROUNDS = int(os.environ.get("RAG_MAX_ROUNDS","3"))
CONFIDENCE_THRESHOLD = float(os.environ.get("RAG_CONF_THRESH","0.6"))

def run_persona(persona: str, chunk_text: str) -> dict:
    proc = subprocess.run([PERSONA_ROUTER, persona, "-"], input=chunk_text.encode('utf-8'), stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    out = proc.stdout.decode('utf-8', errors='replace')
    try:
        return json.loads(out)
    except json.JSONDecodeError:
        return {"_raw_output": out, "_parse_error": True}

def score_persona_outputs(persona_outputs: dict) -> dict:
    weights = {p: 0.25 for p in PERSONAS}
    f = persona_outputs.get("formalist", {})
    if isinstance(f, dict) and f.get("proof_obligations"):
        weights["formalist"] += 0.25
    s = persona_outputs.get("synthesist", {})
    if isinstance(s, dict):
        fs = s.get("fertility_score")
        try:
            if isinstance(fs, (int,float)):
                weights["synthesist"] += min(0.5, fs/10.0)
        except:
            pass
    st = persona_outputs.get("strategist", {})
    if isinstance(st, dict):
        if st.get("traction_risk","").lower()=="low":
            weights["strategist"] += 0.25
        if st.get("leverage_points"):
            weights["strategist"] += 0.1
    a = persona_outputs.get("archivist", {})
    if isinstance(a, dict) and (a.get("tags") or a.get("keep")):
        weights["archivist"] += 0.1
    total = sum(weights.values())
    return {k: round(v/total,3) for k,v in weights.items()}

def curator_debate_and_decide(chunk_text: str) -> dict:
    debate_lines = []
    persona_outputs = {}
    for r in range(1, MAX_ROUNDS+1):
        debate_lines.append(f"=== ROUND {r} — {datetime.datetime.utcnow().isoformat()} ===\n")
        for p in PERSONAS:
            debate_lines.append(f"-- {p.upper()} START --\n")
            out = run_persona(p, chunk_text)
            persona_outputs[p]=out
            try:
                debate_lines.append(json.dumps(out, indent=2, ensure_ascii=False)+"\n")
            except:
                debate_lines.append(repr(out)+"\n")
            debate_lines.append(f"-- {p.upper()} END --\n\n")
        weights = score_persona_outputs(persona_outputs)
        top = max(weights, key=lambda k: weights[k])
        debate_lines.append(f"Round {r} weights: {json.dumps(weights)}\n")
        if weights[top] >= CONFIDENCE_THRESHOLD:
            decision = {"primary_owner": top, "weights": weights, "rounds": r}
            return {"decision": decision, "debate_log": "".join(debate_lines), "persona_outputs": persona_outputs}
        debate_lines.append("Not confident enough, continuing to next round.\n")
    weights = score_persona_outputs(persona_outputs)
    top = max(weights, key=lambda k: weights[k])
    return {"decision": {"primary_owner": top, "weights": weights, "rounds": MAX_ROUNDS}, "debate_log": "".join(debate_lines), "persona_outputs": persona_outputs}

if __name__=='__main__':
    if len(sys.argv)>1 and sys.argv[1] != '-':
        with open(sys.argv[1],'r',encoding='utf-8') as f:
            chunk=f.read()
    else:
        chunk=sys.stdin.read()
    print(json.dumps(curator_debate_and_decide(chunk), indent=2, ensure_ascii=False))
