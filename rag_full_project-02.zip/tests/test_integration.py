import json, os
def test_sample_memory_exists():
    p = "to_process/memories/sample-1.memory"
    assert os.path.exists(p)
    data = json.load(open(p))
    assert "memory_id" in data
